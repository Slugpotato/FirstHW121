package com.dealfaro.luca.clicker;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity {


    //ArrayList<String> numbers = new ArrayList<>();
    TextView txt;
    //private String[] numbers = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void clickButton(View v) {
        Button button;

        // button1
        button = (Button) findViewById(R.id.b1);
        button.setOnClickListener(one);

        // button2
        button = (Button) findViewById(R.id.b2);
        button.setOnClickListener(two);

        // button3
        button = (Button) findViewById(R.id.b3);
        button.setOnClickListener(three);

        // button4
        button = (Button) findViewById(R.id.b4);
        button.setOnClickListener(four);

        // button5
        button = (Button) findViewById(R.id.b5);
        button.setOnClickListener(five);

        // button6
        button = (Button) findViewById(R.id.b6);
        button.setOnClickListener(six);

        // button7
        button = (Button) findViewById(R.id.b7);
        button.setOnClickListener(seven);

        // button8
        button = (Button) findViewById(R.id.b8);
        button.setOnClickListener(eight);

        // button9
        button = (Button) findViewById(R.id.b9);
        button.setOnClickListener(nine);

        // button0
        button = (Button) findViewById(R.id.b0);
        button.setOnClickListener(zero);

        // Delete button #e70d0d
        button = (Button) findViewById(R.id.del);
        button.setOnClickListener(delete);

        // Call Button #27C919
        button = (Button) findViewById(R.id.call);
        button.setOnClickListener(callin);

        // Pound key
        button = (Button) findViewById(R.id.hasht);
        button.setOnClickListener(hashtag);

        // Plus key
        button = (Button) findViewById(R.id.plusss);
        button.setOnClickListener(pluss);

        // TextView
        txt=(TextView) findViewById(R.id.textView);


    }



    View.OnClickListener one = new View.OnClickListener() {
        public void onClick(View v) {

                txt.setText(txt.getText() + "1");

        }
    };

    View.OnClickListener two = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(txt.getText()+"2");


        }
    };

    View.OnClickListener three = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(txt.getText()+"3");


        }
    };

    View.OnClickListener four = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(txt.getText()+"4");
        }
    };

    View.OnClickListener five = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(txt.getText()+"5");

        }
    };

    View.OnClickListener six = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(txt.getText()+"6");

        }
    };

    View.OnClickListener seven = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(txt.getText()+"7");
        }
    };

    View.OnClickListener eight = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(txt.getText()+"8");

        }
    };

    View.OnClickListener nine = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(txt.getText()+"9");

        }
    };

    View.OnClickListener zero = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(txt.getText()+"0");

        }
    };


    View.OnClickListener callin = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(null);


        }
    };


    View.OnClickListener delete = new View.OnClickListener() {
        public void onClick(View v) {

            String textInBox = txt.getText().toString();
            if(textInBox.length() > 0) {
                //Remove last character//
                String newText = textInBox.substring(0, textInBox.length() - 1);
                // Update edit text
                txt.setText(newText);
            }


        }
    };

    View.OnClickListener hashtag = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(txt.getText()+"#");


        }
    };

    View.OnClickListener pluss = new View.OnClickListener() {
        public void onClick(View v) {

            txt.setText(txt.getText()+"+");


        }
    };



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
